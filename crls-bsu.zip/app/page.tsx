import Link from "next/link"
import { Instagram } from "lucide-react"
import { Button } from "@/components/ui/button"
import HeroSection from "@/components/hero-section"
import HistoryTimeline from "@/components/history-timeline"
import CultureGallery from "@/components/culture-gallery"
import AboutSection from "@/components/about-section"
import JoinSection from "@/components/join-section"
import BsuActivities from "@/components/bsu-activities"
import InstagramFeed from "@/components/instagram-feed"
import MobileMenu from "@/components/mobile-menu"

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white">
      <header className="container mx-auto py-6 px-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="h-12 w-12 rounded-full overflow-hidden border-2 border-red-600">
            <img src="/images/bsu-logo.png" alt="CRLS BSU Logo" className="h-full w-full object-cover" />
          </div>
          <h1 className="text-2xl font-bold">CRLS BSU</h1>
        </div>
        <nav className="hidden md:flex gap-6">
          <Link href="#about" className="hover:text-red-500 transition-colors">
            About
          </Link>
          <Link href="#activities" className="hover:text-red-500 transition-colors">
            What We Do
          </Link>
          <Link href="#instagram" className="hover:text-red-500 transition-colors">
            Instagram
          </Link>
          <Link href="#history" className="hover:text-red-500 transition-colors">
            History
          </Link>
          <Link href="#culture" className="hover:text-red-500 transition-colors">
            Culture
          </Link>
          <Link href="#join" className="hover:text-red-500 transition-colors">
            Join Us
          </Link>
        </nav>
        <div className="flex items-center gap-2">
          <Link href="https://instagram.com/crls.bsu" target="_blank" rel="noopener noreferrer">
            <Button variant="ghost" size="icon" className="text-white hover:text-red-500">
              <Instagram className="h-5 w-5" />
              <span className="sr-only">Instagram</span>
            </Button>
          </Link>
          <MobileMenu />
        </div>
      </header>

      <main>
        <HeroSection />

        <section id="about" className="py-20 bg-zinc-900">
          <AboutSection />
        </section>

        <section id="activities" className="py-20">
          <BsuActivities />
        </section>

        <section id="instagram" className="py-20 bg-zinc-900">
          <InstagramFeed />
        </section>

        <section id="history" className="py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-4xl font-bold mb-12 text-center">Black History Timeline</h2>
            <HistoryTimeline />
          </div>
        </section>

        <section id="culture" className="py-20 bg-zinc-900">
          <div className="container mx-auto px-4">
            <h2 className="text-4xl font-bold mb-12 text-center">Black Culture Gallery</h2>
            <CultureGallery />
          </div>
        </section>

        <section id="join" className="py-20">
          <JoinSection />
        </section>
      </main>

      <footer className="bg-zinc-900 py-10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <h2 className="text-xl font-bold">CRLS Black Student Union</h2>
              <p className="text-zinc-400">Cambridge Ridge and Latin School</p>
            </div>
            <div className="flex flex-col items-center md:items-end">
              <div className="flex gap-4 mb-4">
                <Link href="https://instagram.com/crls.bsu" target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="icon" className="rounded-full">
                    <Instagram className="h-5 w-5" />
                    <span className="sr-only">Instagram</span>
                  </Button>
                </Link>
              </div>
              <div className="flex flex-col items-center md:items-end">
                <p className="text-zinc-400 text-sm">© {new Date().getFullYear()} CRLS BSU. All rights reserved.</p>
                <p className="text-zinc-400 text-sm mt-1">Website created by Abenezer Benniame</p>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
