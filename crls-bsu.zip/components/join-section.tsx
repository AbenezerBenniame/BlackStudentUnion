"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Calendar, Clock, MapPin } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export default function JoinSection() {
  const [email, setEmail] = useState("")
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the email to your backend
    setSubmitted(true)
  }

  // Upcoming events based on Instagram posts
  const upcomingEvents = [
    {
      title: "5th Annual Fundraiser",
      date: "May 9",
      time: "All Day",
      location: "Online",
      image: "/images/fundraiser.jpeg",
      description:
        "Link is in bio to donate! We are proud to announce that our 2025 fundraiser will benefit the Cambridge Economic Opportunity Committee (CEOC). Help us reach our goal of $10,000 by Friday, May 9th!",
    },
  ]

  return (
    <div className="container mx-auto px-4">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-4xl font-bold mb-6 text-center">Join CRLS BSU</h2>
        <p className="text-xl text-center max-w-3xl mx-auto mb-12 text-zinc-300">
          Become part of our community and help us celebrate Black excellence at Cambridge Ridge and Latin School.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-bold mb-6">Meeting Information</h3>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <Calendar className="h-6 w-6 text-red-500 mt-1" />
                <div>
                  <h4 className="font-bold">Meeting Days</h4>
                  <p className="text-zinc-300">Every Wednesday</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Clock className="h-6 w-6 text-red-500 mt-1" />
                <div>
                  <h4 className="font-bold">Meeting Time</h4>
                  <p className="text-zinc-300">3:15 PM - 4:00 PM</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <MapPin className="h-6 w-6 text-red-500 mt-1" />
                <div>
                  <h4 className="font-bold">Location</h4>
                  <p className="text-zinc-300">Room 2201, Cambridge Ridge and Latin School</p>
                </div>
              </div>

              <div className="mt-6">
                <h4 className="font-bold mb-2">Join Our Google Classroom</h4>
                <Button asChild className="bg-red-700 hover:bg-red-800">
                  <a
                    href="https://classroom.google.com/u/0/c/NjIzMDk0NzA3NjU5"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="lucide lucide-school"
                    >
                      <path d="m4 6 8-4 8 4" />
                      <path d="m18 10 4 2v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-8l4-2" />
                      <path d="M14 22v-4a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v4" />
                      <path d="M18 5v17" />
                      <path d="M6 5v17" />
                      <circle cx="12" cy="9" r="2" />
                    </svg>
                    Google Classroom
                  </a>
                </Button>
                <p className="text-zinc-300 mt-2">Access resources, assignments, and discussions</p>
              </div>
            </div>

            <div className="mt-8">
              <h3 className="text-2xl font-bold mb-4">Upcoming Events</h3>
              <div className="space-y-4">
                {upcomingEvents.map((event, index) => (
                  <Card key={index} className="bg-zinc-800 border-zinc-700">
                    <CardContent className="p-4">
                      <div className="mb-4 rounded overflow-hidden">
                        <img
                          src={event.image || "/placeholder.svg"}
                          alt={event.title}
                          className="w-full h-auto object-cover"
                        />
                      </div>
                      <div>
                        <h4 className="font-bold text-yellow-400 text-xl mb-2">{event.title}</h4>
                        {event.description && <p className="text-sm text-zinc-300 mb-3">{event.description}</p>}
                        <div className="text-sm text-zinc-300 flex flex-wrap gap-4">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            <span>{event.date}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            <span>{event.time}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            <span>{event.location}</span>
                          </div>
                        </div>
                        <div className="mt-3">
                          <Button asChild size="sm" className="bg-red-700 hover:bg-red-800">
                            <a
                              href="https://qrco.de/cycbsu25"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-2"
                            >
                              Donate Now
                            </a>
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="mt-8">
              <h3 className="text-2xl font-bold mb-4">Contact Us</h3>
              <p className="text-zinc-300 mb-2">Have questions? Reach out to us:</p>
              <p className="text-zinc-300">
                Instagram:{" "}
                <a href="https://instagram.com/crls.bsu" className="text-red-500 hover:underline">
                  @crls.bsu
                </a>
              </p>
            </div>
          </div>

          <div>
            <h3 className="text-2xl font-bold mb-6">Stay Updated</h3>
            {submitted ? (
              <div className="bg-green-900/30 border border-green-700 rounded-lg p-6 text-center">
                <h4 className="text-xl font-bold mb-2">Thank You!</h4>
                <p className="text-zinc-300">
                  We've received your email. You'll be the first to know about our upcoming events and activities.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="email" className="block mb-2">
                    Email Address
                  </label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your.email@example.com"
                    required
                    className="bg-zinc-800 border-zinc-700"
                  />
                </div>

                <div>
                  <label htmlFor="message" className="block mb-2">
                    Message (Optional)
                  </label>
                  <Textarea
                    id="message"
                    placeholder="Tell us why you're interested in joining BSU..."
                    className="bg-zinc-800 border-zinc-700"
                  />
                </div>

                <Button type="submit" className="w-full bg-red-700 hover:bg-red-800">
                  Subscribe to Updates
                </Button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
