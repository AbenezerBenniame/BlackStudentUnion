"use client"

import { useState } from "react"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function MobileMenu() {
  const [isOpen, setIsOpen] = useState(false)

  const toggleMenu = () => {
    setIsOpen(!isOpen)
  }

  const closeMenu = () => {
    setIsOpen(false)
  }

  return (
    <div className="md:hidden">
      <Button variant="ghost" size="icon" onClick={toggleMenu} className="text-white">
        <Menu className="h-6 w-6" />
        <span className="sr-only">Toggle menu</span>
      </Button>

      {isOpen && (
        <div className="fixed inset-0 bg-black z-50 flex flex-col">
          <div className="flex justify-end p-4">
            <Button variant="ghost" size="icon" onClick={closeMenu} className="text-white">
              <X className="h-6 w-6" />
              <span className="sr-only">Close menu</span>
            </Button>
          </div>
          <nav className="flex flex-col items-center justify-center gap-8 flex-1">
            <Link href="#about" onClick={closeMenu} className="text-2xl font-bold hover:text-red-500 transition-colors">
              About
            </Link>
            <Link
              href="#activities"
              onClick={closeMenu}
              className="text-2xl font-bold hover:text-red-500 transition-colors"
            >
              What We Do
            </Link>
            <Link
              href="#instagram"
              onClick={closeMenu}
              className="text-2xl font-bold hover:text-red-500 transition-colors"
            >
              Instagram
            </Link>
            <Link
              href="#history"
              onClick={closeMenu}
              className="text-2xl font-bold hover:text-red-500 transition-colors"
            >
              History
            </Link>
            <Link
              href="#culture"
              onClick={closeMenu}
              className="text-2xl font-bold hover:text-red-500 transition-colors"
            >
              Culture
            </Link>
            <Link href="#join" onClick={closeMenu} className="text-2xl font-bold hover:text-red-500 transition-colors">
              Join Us
            </Link>
          </nav>
        </div>
      )}
    </div>
  )
}
