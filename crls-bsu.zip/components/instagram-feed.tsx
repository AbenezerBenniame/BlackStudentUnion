"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Instagram, Heart, Share2, Bookmark } from "lucide-react"
import { Button } from "@/components/ui/button"

// Real Instagram posts from crls.bsu, reordered as requested
const instagramPosts = [
  {
    id: "post5",
    image: "/images/instagram-post-5.png",
    caption:
      "Link is in bio to donate! We are proud to announce that our 2025 fundraiser will benefit the Cambridge Economic Opportunity...",
    date: "April 10",
  },
  {
    id: "post3",
    image: "/images/instagram-post-3.png",
    caption:
      "Hello BSU! Join us this Wednesday for our member-led desk @ 3:15 at Room 2201. As you know it, we have few desks remaining this year. So make sure to show up!",
    date: "6 days ago",
  },
  {
    id: "post4",
    image: "/images/instagram-post-4.png",
    caption:
      "Hey BSU! Join us this Wednesday @ 3:15 at ROOM 2201 for our member-led desk, facilitated by Sarah & Omer! (Beware: the Desk isn't exactly how it sounds...)",
    date: "April 13",
  },
  {
    id: "post1",
    image: "/images/instagram-post-1.png",
    caption:
      "What's up BSU! Are y'all ready for our second member-led DESK of the month? Get ready for Who's Invited To The Cookout, organized by Eli and...",
    date: "April 10",
  },
  {
    id: "post2",
    image: "/images/instagram-post-2.png",
    caption:
      "Calling all leaders! BSU Leadership Applications are officially LIVE! This is your chance to step into a role where your voice matters. For the rising seniors and juniors—We're looking for passionate folks to join the team. 📋 Apps are due by May 2nd at 11:59 PM — don't sleep on it!",
    date: "April 20",
  },
  {
    id: "post6",
    image: "/images/instagram-post-6.png",
    caption:
      "Hello BSU! Join us for our First MEMBER Lead Desk. Camille will be facilitating conversation about the usage of AAVE (African American Vernacular English). See you on Wednesday! 😉",
    date: "March 30",
  },
]

export default function InstagramFeed() {
  const [showAll, setShowAll] = useState(false)
  const displayPosts = showAll ? instagramPosts : instagramPosts.slice(0, 3)

  const handleShare = (post: any) => {
    if (navigator.share) {
      navigator
        .share({
          title: "CRLS BSU Instagram Post",
          text: post.caption,
          url: "https://instagram.com/crls.bsu",
        })
        .then(() => console.log("Successful share"))
        .catch((error) => console.log("Error sharing", error))
    } else {
      window.open("https://instagram.com/crls.bsu", "_blank")
    }
  }

  return (
    <div className="container mx-auto px-4">
      <div className="flex items-center justify-center gap-2 mb-8">
        <Instagram className="h-6 w-6 text-red-500" />
        <h2 className="text-3xl font-bold text-center">@crls.bsu Instagram</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {displayPosts.map((post) => (
          <Card
            key={post.id}
            className="overflow-hidden bg-zinc-800 border-zinc-700 hover:border-yellow-400 transition-colors"
          >
            <div className="p-3 flex items-center gap-2 border-b border-zinc-700">
              <div className="h-8 w-8 rounded-full overflow-hidden">
                <img src="/images/bsu-logo.png" alt="CRLS BSU" className="h-full w-full object-cover" />
              </div>
              <span className="font-medium">crls.bsu</span>
            </div>
            <div className="aspect-square overflow-hidden">
              <img src={post.image || "/placeholder.svg"} alt="Instagram post" className="w-full h-full object-cover" />
            </div>
            <div className="p-3 flex items-center justify-between border-b border-zinc-700">
              <div className="flex items-center gap-4">
                <button className="flex items-center gap-1 text-zinc-300 hover:text-red-500">
                  <Heart className="h-5 w-5" />
                </button>
                <button
                  className="flex items-center gap-1 text-zinc-300 hover:text-blue-500"
                  onClick={() => handleShare(post)}
                >
                  <Share2 className="h-5 w-5" />
                </button>
              </div>
              <button className="text-zinc-300 hover:text-yellow-400">
                <Bookmark className="h-5 w-5" />
              </button>
            </div>
            <CardContent className="p-4">
              <p className="text-zinc-300 text-sm mb-2">
                <span className="font-medium text-white">crls.bsu</span> {post.caption}
              </p>
              <p className="text-zinc-500 text-xs">{post.date}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {!showAll && instagramPosts.length > 3 && (
        <div className="mt-8 text-center">
          <Button onClick={() => setShowAll(true)} className="bg-red-700 hover:bg-red-800">
            View More Posts
          </Button>
        </div>
      )}

      <div className="mt-8 text-center">
        <Button asChild variant="outline">
          <a
            href="https://instagram.com/crls.bsu"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2"
          >
            <Instagram className="h-5 w-5" />
            Follow Us on Instagram
          </a>
        </Button>
      </div>
    </div>
  )
}
