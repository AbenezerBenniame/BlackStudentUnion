import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function HeroSection() {
  return (
    <div className="relative h-[80vh] flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 to-black z-10"></div>
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: "url('/images/hero-bg.jpg')" }}
      ></div>
      <div className="container mx-auto px-4 z-20 text-center">
        <div className="w-32 h-32 mx-auto mb-6 rounded-full overflow-hidden border-4 border-red-600">
          <img src="/images/bsu-logo.png" alt="CRLS BSU Logo" className="w-full h-full object-cover" />
        </div>
        <h1 className="text-5xl md:text-7xl font-bold mb-6">
          <span className="text-red-600">Black</span> Student Union
        </h1>
        <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
          Celebrating and preserving Black history, culture, and excellence at Cambridge Ridge and Latin School
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild size="lg" className="bg-red-700 hover:bg-red-800">
            <Link href="#join">Join Our Community</Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link href="#history">Explore Black History</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
