import { Card, CardContent } from "@/components/ui/card"
import { Calendar } from "lucide-react"

// Activities based on the actual Instagram posts
const bsuActivities = [
  {
    title: "Kamala vs. Trump Discussion",
    image: "/images/activity-1.png",
    description:
      "A collaborative DESK with Political Awareness Club and Intersectional Feminism Club discussing the presidential election and its implications.",
    date: "October 30, 3:15 PM, Room 2201",
  },
  {
    title: "Things the Black Community Needs to Leave in 2024",
    image: "/images/activity-2.png",
    description:
      "Our first meeting of the year where we'll debrief on the good and bad of 2024 and discuss what the Black community should leave behind.",
    date: "Wednesday, 3:15 PM, Room 2201",
  },
  {
    title: "Black Legacy in Trump's America",
    image: "/images/activity-3.png",
    description:
      "A collaboration with HarvAfro exploring Black legacy and achievement in America, featuring discussions about influential Black figures and their impact.",
    date: "February 26, 3:15 PM, Room 2201",
  },
  {
    title: "BSU Spirit Week",
    image: "/images/activity-4.png",
    description:
      "A week-long celebration featuring themed days: BSU Hoodie Day, Culture Day, Dress to Impress, Throwback Thursday, and Black Out.",
    date: "February 24-28",
  },
  {
    title: "The African Diaspora",
    image: "/images/activity-5.png",
    description:
      "A collaboration with East African Club exploring the African Diaspora, its history, and its cultural significance across the world.",
    date: "Wednesday, 3:15 PM, Room 2201",
  },
  {
    title: "MLK vs Malcolm X: Styles of Activism",
    image: "/images/activity-6.png",
    description:
      "A discussion comparing the different approaches to activism championed by Dr. Martin Luther King Jr. and Malcolm X, examining which style might be more effective.",
    date: "Wednesday, 3:15 PM, Room 2201",
  },
]

export default function BsuActivities() {
  return (
    <div className="container mx-auto px-4">
      <h2 className="text-4xl font-bold mb-6 text-center">What We Do</h2>
      <p className="text-xl text-center max-w-3xl mx-auto mb-12 text-zinc-300">
        The CRLS Black Student Union organizes various activities and events throughout the year to celebrate Black
        culture, provide support to our members, and educate the wider community through meaningful discussions and
        collaborations.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {bsuActivities.map((activity, index) => (
          <Card
            key={index}
            className="overflow-hidden bg-zinc-800 border-zinc-700 hover:border-yellow-400 transition-colors"
          >
            <div className="h-48 overflow-hidden">
              <img
                src={activity.image || "/placeholder.svg"}
                alt={activity.title}
                className="w-full h-full object-cover transition-transform hover:scale-105"
              />
            </div>
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-2 text-yellow-400">{activity.title}</h3>
              <p className="text-zinc-300 mb-4">{activity.description}</p>
              <div className="flex items-center text-sm text-zinc-400">
                <Calendar className="h-4 w-4 mr-2" />
                <span>{activity.date}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-12 text-center">
        <p className="text-lg text-zinc-300 mb-4">
          Follow us on Instagram{" "}
          <a href="https://instagram.com/crls.bsu" className="text-red-500 hover:underline">
            @crls.bsu
          </a>{" "}
          to stay updated on all our activities and events!
        </p>
      </div>
    </div>
  )
}
