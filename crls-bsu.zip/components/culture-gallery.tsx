import { Card, CardContent } from "@/components/ui/card"

const cultureCategories = [
  {
    title: "Literature",
    image: "/images/culture-literature.jpg",
    description:
      "Black authors like Richard Wright, James Baldwin, and Toni Morrison have created powerful works that explore identity, struggle, and triumph throughout history.",
  },
  {
    title: "Fashion",
    image: "/images/culture-fashion.jpg",
    description:
      "From traditional African textiles to modern runway innovations, Black fashion designers and style icons have influenced global trends and redefined beauty standards.",
  },
  {
    title: "Film & Television",
    image: "/images/culture-film.jpg",
    description:
      "Pioneers like Sidney Poitier broke barriers in Hollywood, paving the way for Black filmmakers, actors, and producers to create groundbreaking content that entertains and educates.",
  },
  {
    title: "Dance",
    image: "/images/culture-dance.jpg",
    description:
      "From traditional African dance to modern styles like the Alvin Ailey American Dance Theater, Black dancers have innovated and inspired movements worldwide.",
  },
  {
    title: "Art",
    image: "/images/culture-art.jpg",
    description:
      "Black visual artists like Jacob Lawrence, Jean-Michel Basquiat, and Alma Thomas have created stunning works that reflect the Black experience and challenge perspectives.",
  },
  {
    title: "Music",
    image: "/images/culture-music.jpg",
    description:
      "From early jazz and blues to hip-hop and R&B, Black musicians have pioneered genres that have shaped American music and global culture for generations.",
  },
]

export default function CultureGallery() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {cultureCategories.map((category, index) => (
        <Card
          key={index}
          className="overflow-hidden bg-zinc-800 border-zinc-700 hover:border-yellow-400 transition-colors"
        >
          <div className="h-48 overflow-hidden">
            <img
              src={category.image || "/placeholder.svg"}
              alt={category.title}
              className="w-full h-full object-cover transition-transform hover:scale-105"
            />
          </div>
          <CardContent className="p-6">
            <h3 className="text-xl font-bold mb-2 text-yellow-400">{category.title}</h3>
            <p className="text-zinc-300">{category.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
