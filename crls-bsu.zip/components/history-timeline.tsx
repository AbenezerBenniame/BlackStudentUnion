import { Card, CardContent } from "@/components/ui/card"

const timelineEvents = [
  {
    year: "1619",
    title: "First Africans in English North America",
    description: "The first recorded Africans in English North America arrive in Jamestown, Virginia.",
  },
  {
    year: "1791-1804",
    title: "Haitian Revolution",
    description:
      "The successful slave revolt led to the establishment of Haiti as the first Black republic in the world.",
  },
  {
    year: "1863",
    title: "Emancipation Proclamation",
    description:
      "President Abraham Lincoln issues the Emancipation Proclamation, declaring slaves in Confederate states free.",
  },
  {
    year: "1909",
    title: "NAACP Founded",
    description: "The National Association for the Advancement of Colored People (NAACP) is founded.",
  },
  {
    year: "1954",
    title: "Brown v. Board of Education",
    description: "The Supreme Court rules that racial segregation in public schools is unconstitutional.",
  },
  {
    year: "1955-1956",
    title: "Montgomery Bus Boycott",
    description: "Led by Dr. Martin Luther King Jr., the boycott challenged segregation on public buses.",
  },
  {
    year: "1963",
    title: "March on Washington",
    description:
      "Over 250,000 people gather for the March on Washington where Dr. King delivers his 'I Have a Dream' speech.",
  },
  {
    year: "1964",
    title: "Civil Rights Act",
    description:
      "The Civil Rights Act prohibits discrimination based on race, color, religion, sex, or national origin.",
  },
  {
    year: "1965",
    title: "Voting Rights Act",
    description: "The Voting Rights Act prohibits racial discrimination in voting.",
  },
  {
    year: "2008",
    title: "Barack Obama Elected President",
    description: "Barack Obama becomes the first Black President of the United States.",
  },
  {
    year: "2020",
    title: "Black Lives Matter Movement",
    description:
      "Global protests against racial injustice following the murder of George Floyd spark renewed calls for change.",
  },
]

export default function HistoryTimeline() {
  return (
    <div className="relative">
      <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-red-700"></div>
      <div className="space-y-12">
        {timelineEvents.map((event, index) => (
          <div
            key={index}
            className={`relative flex ${index % 2 === 0 ? "flex-row" : "flex-row-reverse"} items-center`}
          >
            <div className="w-1/2"></div>
            <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 rounded-full bg-red-700 z-10"></div>
            <Card className={`w-1/2 ${index % 2 === 0 ? "mr-8" : "ml-8"} bg-zinc-800 border-zinc-700`}>
              <CardContent className="p-6">
                <div className="text-red-500 font-bold mb-2">{event.year}</div>
                <h3 className="text-xl font-bold mb-2">{event.title}</h3>
                <p className="text-zinc-300">{event.description}</p>
              </CardContent>
            </Card>
          </div>
        ))}
      </div>
    </div>
  )
}
