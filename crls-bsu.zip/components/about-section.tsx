import { Card, CardContent } from "@/components/ui/card"
import { Calendar, Users, BookOpen } from "lucide-react"

export default function AboutSection() {
  return (
    <div className="container mx-auto px-4">
      <h2 className="text-4xl font-bold mb-6 text-center">About CRLS BSU</h2>
      <p className="text-xl text-center max-w-3xl mx-auto mb-12 text-zinc-300">
        The Black Student Union at Cambridge Ridge and Latin School is dedicated to creating a space where Black
        students can connect, learn, and celebrate their heritage.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <Card className="bg-zinc-800 border-zinc-700">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <div className="h-12 w-12 rounded-full bg-red-700 flex items-center justify-center mb-4">
                <Users className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">Community</h3>
              <p className="text-zinc-300">
                We provide a supportive community for Black students to connect, share experiences, and build lasting
                friendships.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-800 border-zinc-700">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <div className="h-12 w-12 rounded-full bg-red-700 flex items-center justify-center mb-4">
                <BookOpen className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">Education</h3>
              <p className="text-zinc-300">
                We promote education about Black history, culture, and achievements that are often overlooked in
                traditional curricula.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-800 border-zinc-700">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <div className="h-12 w-12 rounded-full bg-red-700 flex items-center justify-center mb-4">
                <Calendar className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">Events</h3>
              <p className="text-zinc-300">
                We organize events, discussions, and celebrations that honor Black excellence and foster cultural
                awareness.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
